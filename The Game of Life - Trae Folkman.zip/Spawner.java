package folkman;

public interface Spawner {
    public Creature spawnNewCreature();
}
